﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.ObjectModel;
using System.Windows.Threading;

namespace RollPitchYaw.ViewModels
{
    internal class Spindle3DViewModel : ObservableObject
    {
        private double _roll; 
        public double Roll
        {
            get => _roll;
            set
            {
                SetProperty(ref _roll, value);
            }
        }

        private double _pitch;
        public double Pitch
        {
            get => _pitch;
            set
            {
                SetProperty(ref _pitch, value);
            }
        }

        private double _yaw;
        public double Yaw
        {
            get => _yaw;
            set
            {
                SetProperty(ref _yaw, value);
            }
        }

        private double _thickness = 0.4;
        public double Thickness
        {
            get => _thickness;
            set
            {
                SetProperty(ref _thickness, value);
            }
        }

        private double _x;
        public double X
        {
            get => _x;
            set => SetProperty(ref _x, value);
        }


        private double _y;
        public double Y
        {
            get => _y;
            set => SetProperty(ref _y, value);
        }

        private double _scale = 1.0;
        public double Scale
        {
            get => _scale;
            set => SetProperty(ref _scale, value);
        }


        private ObservableCollection<SocketViewModel> _sockets;
        public ObservableCollection<SocketViewModel> Sockets
        {
            get => _sockets;
            set => SetProperty(ref _sockets, value);
        }


        public RelayCommand<string> SpindleCommand { get; set; }
        public RelayCommand<string> WaferExistCommand { get; set; }
        public RelayCommand<string> WaferStateCommand { get; set; }

        public Spindle3DViewModel()
        {
            SpindleCommand = new RelayCommand<string>(SpindleCommand_Function);
            WaferExistCommand = new RelayCommand<string>(WaferExistCommand_Function);
            WaferStateCommand = new RelayCommand<string>(WaferStateCommand_Function);

            _rotateTimer = new DispatcherTimer();
            _rotateTimer.Interval = TimeSpan.FromMilliseconds(10);
            _rotateTimer.Tick += rotateTimer_Tick;

            _spindleTimer = new DispatcherTimer();
            _spindleTimer.Interval = TimeSpan.FromMilliseconds(10);
            _spindleTimer.Tick += spindleTimer_Tick;

            _updateTimer = new DispatcherTimer();
            _updateTimer.Interval = TimeSpan.FromMilliseconds(10);
            _updateTimer.Tick += updateTimer_Tick;
            _updateTimer.Start();

            int i = 1;
            Sockets = new ObservableCollection<SocketViewModel>();
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
            Sockets.Add(new SocketViewModel($"{i}", false, $"A{i}")); i++;
        }

        DispatcherTimer _rotateTimer;
        DispatcherTimer _spindleTimer;
        DispatcherTimer _updateTimer;
        bool _spindleStart = true;
        double MOVE_UNIT = 0.5;
        double START_LIMIT = -90;
        double STOP_LIMIT = 0;

        void SpindleCommand_Function(string para)
        {
            _spindleTimer.Stop();
            switch (para.ToLower())
            {
                case "start":
                    _spindleStart = true;
                    break;

                case "stop":
                    _spindleStart = false;
                    break;
            }
            _rotateTimer.Start();
            _spindleTimer.Start();
        }

        void WaferExistCommand_Function(string para)
        {
            string[] ss = para.Split(',');
            int.TryParse(ss[1], out int idx);
            idx -= 1;
            if (ss[0] == "N")
            {
                Sockets[idx].WaferExist = false;
            }
            else
            {
                Sockets[idx].WaferExist = true;
            }
        }

        void WaferStateCommand_Function(string para)
        {
            string[] ss = para.Split(',');
            int.TryParse(ss[1], out int idx);
            idx -= 1;
            switch (ss[0])
            {
                case "P":
                    Sockets[idx].WaferState = "Processed";
                    break;
                
                default:
                    Sockets[idx].WaferState = "Unknown";
                    break;
            }
        }

        void RefreshData()
        {
            // Thickness가 Update되야지만 변경사항이 적용되고 있음
            // 3D 효과를 내기위해 적용한 부분에 의해 영향을 받는것 같은데
            // 현재(2025-05-15) 원인은 모름...
            OnPropertyChanged(nameof(Thickness));
        }

        void updateTimer_Tick(object sender, EventArgs e)
        {
            foreach (var s in Sockets)
            {
                s.WaferAngle = Roll;
            }

            RefreshData();
        }

        void rotateTimer_Tick(object sender, EventArgs e)
        {
            Roll = (Roll + 4) % 360;
        }

        void spindleTimer_Tick(object sender, EventArgs e)
        {
            bool completed = false;

            if (_spindleStart)
            {
                if (Pitch > START_LIMIT)
                {
                    completed = false;
                    Pitch -= MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    Pitch = START_LIMIT;
                }

                if (Yaw > START_LIMIT)
                {
                    completed = false;
                    Yaw -= MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    Yaw = START_LIMIT;
                }

                if (X > START_LIMIT)
                {
                    completed = false;
                    X -= MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    X = START_LIMIT;
                }

                if (Y > START_LIMIT)
                {
                    completed = false;
                    Y -= MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    Y = START_LIMIT;
                }

            }
            else
            {
                if (Pitch < STOP_LIMIT)
                {
                    completed = false;
                    Pitch += MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    Pitch = STOP_LIMIT;
                }

                if (Yaw < STOP_LIMIT)
                {
                    completed = false;
                    Yaw += MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    Yaw = STOP_LIMIT;
                }

                if (X < STOP_LIMIT)
                {
                    completed = false;
                    X += MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    X = STOP_LIMIT;
                }

                if (Y < STOP_LIMIT)
                {
                    completed = false;
                    Y += MOVE_UNIT;
                }
                else
                {
                    completed = true;
                    Y = STOP_LIMIT;
                }
            }

            if (completed)
            {
                if (_spindleStart)
                {
                    _spindleTimer.Stop();
                }
                else
                {
                    Roll = 0;
                    _rotateTimer.Stop();
                    _spindleTimer.Stop();
                }
            }
        }

    }

}
