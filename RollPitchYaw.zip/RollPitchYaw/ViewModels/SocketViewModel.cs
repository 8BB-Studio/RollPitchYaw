﻿using CommunityToolkit.Mvvm.ComponentModel;
using System.Windows.Media;

namespace RollPitchYaw.ViewModels
{
    internal class SocketViewModel : ObservableObject
    {       
        private string _index;
        public string Index
        {
            get => _index;
            set => SetProperty(ref _index, value);
        }

        private bool _waferExist;
        public bool WaferExist
        {
            get => _waferExist;
            set => SetProperty(ref _waferExist, value);
        }

        private string _waferID;
        public string WaferID
        {
            get => _waferID;
            set => SetProperty(ref _waferID, value);
        }

        private double _waferAngle;
        public double WaferAngle
        {
            get => _waferAngle;
            set => SetProperty(ref _waferAngle, value);
        }

        private string _waferState = "";
        public string WaferState
        {
            get => _waferState;
            set
            {
                SetProperty(ref _waferState, value);
                WaferColor = WaferStateToColor(value);
            }
        }

        private Brush _waferColor = Brushes.AliceBlue;
        public Brush WaferColor
        {
            get => _waferColor;
            set => SetProperty(ref _waferColor, value);
        }

        public SocketViewModel(string socketIndex, bool waferExist, string waferID, string waferState = "")
        {
            Index = socketIndex;
            WaferExist = waferExist;
            WaferID = waferID;
            WaferColor = WaferStateToColor(WaferState);
        }

        Brush WaferStateToColor(string state)
        {
            switch (state.ToLower())
            {
                case "processed":
                    return new SolidColorBrush(Colors.Violet);

                default:
                    return new SolidColorBrush(Colors.Blue);
            }
        }
    }
}
