﻿using MVVM_Base;
using System.Windows.Media;

namespace RollPitchYaw.ViewModels
{
    internal class SocketViewModel : ViewModelBase
    {       
        private string _index;
        public string Index
        {
            get => _index;
            set
            {
                _index = value;
                OnPropertyChanged();
            }
        }

        private bool _waferExist;
        public bool WaferExist
        {
            get => _waferExist;
            set
            {
                _waferExist = value;
                OnPropertyChanged();
            }
        }

        private string _waferID;
        public string WaferID
        {
            get => _waferID;
            set
            {
                _waferID = value;
                OnPropertyChanged();
            }
        }

        private double _waferAngle;
        public double WaferAngle
        {
            get => _waferAngle;
            set
            {
                _waferAngle = value;
                OnPropertyChanged();
            }
        }

        private string _waferState = "";
        public string WaferState
        {
            get => _waferState;
            set
            {
                _waferState = value;
                OnPropertyChanged();
                WaferColor = WaferStateToColor(value);
            }
        }

        private Brush _waferColor = Brushes.AliceBlue;
        public Brush WaferColor
        {
            get => _waferColor;
            set
            {
                _waferColor = value;
                OnPropertyChanged();
            }
        }

        public SocketViewModel(string socketIndex, bool waferExist, string waferID, string waferState = "")
        {
            Index = socketIndex;
            WaferExist = waferExist;
            WaferID = waferID;
            WaferColor = WaferStateToColor(WaferState);
        }

        Brush WaferStateToColor(string state)
        {
            switch (state.ToLower())
            {
                case "processed":
                    return new SolidColorBrush(Colors.Violet);

                default:
                    return new SolidColorBrush(Colors.Blue);
            }
        }
    }
}
