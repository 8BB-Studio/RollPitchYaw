﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace RollPitchYaw.Converters
{
    public class BoolToVisibilityConverter : IValueConverter
    {
        public bool Inverted { get; set; } = false;
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool booleanValue)
            {
                if (Inverted)
                {
                    booleanValue = !booleanValue;
                }
                return booleanValue ? Visibility.Visible : Visibility.Hidden;
            }

            // 기본값 (예외 처리)
            return Visibility.Hidden;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Visibility visibility)
            {
                return visibility == Visibility.Visible;
            }

            // 기본값 (예외 처리)
            return false;
        }
    }
}
